﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Assig1.Data;
using Assig1.Models;
using System.ComponentModel;
using Swashbuckle.AspNetCore.SwaggerGen;
using System.Diagnostics;

namespace Assig1.Controllers.API
{
    /* 
     * If you would like to create D3 graphs from the data use this controller.
     * All actions in this controller must be requested using "/api/Graphs/[actionName]"
     * Pass parameters into your actions via queryStrings
     */

    [Route("api/[controller]/[action]")]
    [ApiController]
    public class GraphsController : Controller
    {
        private readonly ExpiationsContext _context;

        public GraphsController(ExpiationsContext context)
        {
            _context = context;
        }
        /// <summary>
        /// Gets a list of Suburbs that exist in the database.
        /// </summary>
        /// <returns>List of suburbs that contain a Camera</returns>
        // GET: /api/Graphs/Get_ListCameraSuburbs
        [HttpGet(Name = "Get_ListCameraSuburbs")]
        public async Task<object> Get_ListCameraSuburbs()
        {
            var cameraContext = _context.CameraCodes;
            var suburbs = await cameraContext.Select(i => i.Suburb.Split('/', 2, StringSplitOptions.TrimEntries)[0]).ToListAsync();
            return suburbs.Distinct().OrderBy(i => i);
        }

        /// <summary>
        /// Gets a List of Cameras within a given Suburb. Option to return only the list of locationIds + CameraTypes (primary composite key) only.
        /// </summary>
        /// <param name="suburb">The Selected Suburb</param>
        /// <param name="locationIdsOnly">Optional: Narrows the return data to just a list of the locationIds + CameraTypes (pk composite)</param>
        /// <returns>List of Camera's in Suburb. Optionally return only the list of LocationID's</returns>
        // GET: /api/Graphs/Get_ListCamerasInSuburb?suburb=foo&locationIdsOnly=false
        [HttpGet(Name = "Get_ListCamerasInSuburb")]
        public async Task<object> Get_ListCamerasInSuburb(string suburb, bool locationIdsOnly = false)
        {
            var cameraContext = _context.CameraCodes;
            if (suburb == null) { return "ERROR: YOU MUST SUPPLY A SUBURB"; }
            var suburbs = await cameraContext.Where(i => i.Suburb.ToLower().StartsWith(suburb.ToLower())).Select(i => new { i.LocationId, i.CameraTypeCode, i.CameraTypeCodeNavigation.CameraType1, i.Suburb, i.RoadName, i.RoadType }).ToListAsync();

            if (locationIdsOnly)
            {
                return suburbs.Select(i => i.LocationId);
            }

            return suburbs.OrderBy(i => i.LocationId);
        }

        /// <summary>
        /// Gets a List of Offences with a given Description. Option to return only the list of Offence Codes. Offences are the list of Offence types and codes.
        /// </summary>
        /// <param name="searchTerm">The search term to find in the Offences table's Offence.Description</param>
        /// <param name="offenceCodesOnly">Optional: Return only the list of Offence Codes that match the query</param>
        /// <returns>A List of the Offences that contain the searchTerm. Optionally return only the list of the matching Offence codes./returns>
        // GET: /api/Graphs/Get_SearchOffencesByDescription?suburb=foo&locationIdsOnly=false
        [HttpGet(Name = "Get_SearchOffencesByDescription")]
        public async Task<object> Get_SearchOffencesByDescription(string searchTerm = "", bool offenceCodesOnly = false)
        {
            //Try seaching for "Speed" or "Exceed" for speeding offences
            var expiationCategoryContext = _context.Offences;
            var expiationCategories = await expiationCategoryContext.Where(i => i.Description.ToLower().Contains(searchTerm.ToLower())).Select(i => i).ToListAsync();
            if (offenceCodesOnly)
            {
                return expiationCategories.Select(i => i.OffenceCode);
            }
                return expiationCategories.OrderBy(i => i.OffenceCode);
        }


        /// <summary>
        /// Gets a list of Expiations for a given LocationId + Camera Type. Option to return only the list of Offence Codes
        /// </summary>
        /// <param name="locationId">The locationId to use in the Expiation search. A specific camera is a composite of locationId + Camera Type</param>
        /// <param name="startTime">Optional: Return only Offences that happened after this start time. Uses Unix timestamp notation. Defaults to 0 (All Offences)</param>
        /// <param name="endTime">Optional: Return only Offences that happened before this end time. Uses Unix timestamp notation. Defaults to Int32.Max (All Offences)</param>
        /// <param name="offenceCodes">Optional: Return only Offences that include the current offenceCode. Multiple inputs allowed to extend the List. E.g. offenceCodes=A001&amp;offenceCodes=A002 </param>
        /// <returns>List&lt;Expiation&gt;. i.e a List of matching Expiation. Check the relationial diagram on the course website to help determine what fields are contained in the table.</returns>
        // GET: /api/Graphs/Get_ExpiationsForLocationId?locationId=123&startTime=123&endTime=123&offenceCodes=foo&offenceCodes=bar
        [HttpGet(Name = "Get_ExpiationsForLocationId")]
        public async Task<object> Get_ExpiationsForLocationId(int locationId, int startTime=0, int endTime= Int32.MaxValue, List<String>? offenceCodes = null)
        {

            offenceCodes ??= new List<string>(); //Initialize List if it's null / default so we don't start exploding

            var offencesContext = _context.Expiations;
            if (locationId <= 0) { return "ERROR: YOU MUST SUPPLY A VALID LOCATIONID. USE Get_ListCamerasInSuburb"; }
            var offences = offencesContext.Where(i => i.CameraLocationId == locationId).AsEnumerable();

            if (startTime != 0)
            {
                offences = offences.Where(i => DateTimeToUnixTime(i.IncidentStartDate, i.IncidentStartTime) >= startTime);
            }

            if (endTime != Int32.MaxValue)

            {
                offences = offences.Where(i => DateTimeToUnixTime(i.IncidentStartDate, i.IncidentStartTime) <= endTime);
            }

            if (offenceCodes.Count() > 0)
            {
                offences = offences.Where(i => offenceCodes.Contains(i.OffenceCode));
            }

            return await Task.FromResult(offences.ToList());
        }

        /// <summary>
        /// Gets aggregated stats for a given LocationId + CameraType
        /// </summary>
        /// <param name="locationId">The locationId to use in the Expiation search. A specific camera is a composite of locationId + Camera Type</param>
        /// <param name="startTime">Optional: Return only Offences that happened after this start time. Uses Unix timestamp notation. Defaults to 0 (All Offences)</param>
        /// <param name="endTime">Optional: Return only Offences that happened before this end time. Uses Unix timestamp notation. Defaults to Int32.Max (All Offences)</param>
        /// <param name="offenceCodes">Optional: Return only Offences that include the current offenceCode. Multiple inputs allowed to extend the List. E.g. offenceCodes=A001&amp;offenceCodes=A002 </param>
        /// <returns>totalOffencesCount, totalDemerits, totalFeeSum, avgDemeritsPerDay, avgFeePerday</returns>
        // GET: /api/Graphs/Get_ExpiationStatsForLocationId?locationId=123&startTime=123&endTime=123&offenceCodes=foo&offenceCodes=bar
        [HttpGet(Name ="Get_ExpiationStatsForLocationId")]
        public async Task<object> Get_ExpiationStatsForLocationId(int locationId, int startTime = 0, int endTime = Int32.MaxValue, List<String>? offenceCodes = null)
        {

            offenceCodes ??= new List<string>(); //Initialize list if it's null / default

            var offencesContext = _context.Expiations;
            var offenceTypesConxet = _context.Offences;
            if (locationId <= 0) { return "ERROR: YOU MUST SUPPLY A VALID LOCATIONID. USE Get_ListCamerasInSuburb"; }
            var offences = offencesContext.Where(i => i.CameraLocationId == locationId).AsEnumerable();

            if (startTime != 0)
            {
                offences = offences.Where(i => DateTimeToUnixTime(i.IncidentStartDate, i.IncidentStartTime) >= startTime);
            }

            if (endTime != Int32.MaxValue)

            {
                offences = offences.Where(i => DateTimeToUnixTime(i.IncidentStartDate, i.IncidentStartTime) <= endTime);
            }

            if (offenceCodes.Count() > 0)
            {
                offences = offences.Where(i => offenceCodes.Contains(i.OffenceCode));
            }

            System.Diagnostics.Debug.Assert(offences.Count() > 0, "No offences found...");

            offences = offences.OrderBy(i => i.IncidentStartDate).ThenBy(i => i.IncidentStartTime);

            var totalFeeSum = offences.Sum(i => i.TotalFeeAmt);
            var totalOffencesCount = offences.Count();
            int totalDemerits = 0;
            var DemeritsDict = new Dictionary<string, int> { [""]=0 };
            double avgDemeritsPerDay = 0;
            double avgFeePerDay = 0;

            foreach (var offence in offenceCodes)
            {
                DemeritsDict[offence] = (int)offenceTypesConxet.Where(i => i.OffenceCode == offence).Select(i => i.DemeritPoints).FirstOrDefault(0);
                //Eh, you can optimise this if you want. Select everything from the DB first, then do this. Rather than hit the database for each offenceCode
            }

            foreach (var expiation in offences.Select(i => i.OffenceCode))
            {
               
                totalDemerits += DemeritsDict.GetValueOrDefault(expiation ?? "", 0);
            }

            int firstExpiationInSet = DateTimeToUnixTime(offences.First().IncidentStartDate, offences.First().IncidentStartTime);
            int LastExpiationInSet = DateTimeToUnixTime(offences.Last().IncidentStartDate, offences.Last().IncidentStartTime);
            int diff = LastExpiationInSet - firstExpiationInSet;

            avgDemeritsPerDay = 86400d / (double)diff * totalDemerits;
            avgFeePerDay = 86400d / (double)diff * (totalFeeSum ??= 0);


            return new { totalOffencesCount, totalDemerits, totalFeeSum, avgDemeritsPerDay, avgFeePerDay};
        }

/*
        [HttpGet(Name = "Get_OffencesForSuburb")]
        //Be extra careful with this one. You'll get a LOT of results if you don't scope the startTime and endTime appropriately!!
        public async Task<object> Get_OffencesForCameraId(string suburb, int startTime = 0, int endTime = Int32.MaxValue, List<String>? offenceCodes = null)
        {

            offenceCodes ??= new List<string>(); //Initialize list if it's null / default

            var offencesContext = _context.Expiations;
            if (locationId <= 0) { return "ERROR: YOU MUST SUPPLY A VALID LOCATIONID. USE Get_ListCamerasInSuburb"; }
            var offences = offencesContext.Where(i => i.CameraLocationId == locationId).AsEnumerable();

            if (startTime != 0)
            {
                offences = offences.Where(i => DateTimeToUnixTime(i.IncidentStartDate, i.IncidentStartTime) >= startTime);
            }

            if (endTime != Int32.MaxValue)

            {
                offences = offences.Where(i => DateTimeToUnixTime(i.IncidentStartDate, i.IncidentStartTime) <= endTime);
            }

            if (offenceCodes.Count() > 0)
            {
                offences = offences.Where(i => offenceCodes.Contains(i.OffenceCode));
            }

            return await Task.FromResult(offences.ToList());
        }
*/


        public static int DateTimeToUnixTime(DateOnly date, TimeOnly time)
        {
            DateTime combined = new DateTime(date, time);
            
            int unixTime = (int)((DateTimeOffset)combined).ToUnixTimeSeconds();
            return unixTime;
        }


        /* Get offences for given suburb
        public async Task<object> CamerasInSuburb(string suburb)
        {
            var cameraContext = _context.CameraCodes;
            var suburbs = await cameraContext.Where(i => i.Suburb.ToLower().StartsWith(suburb.ToLower())).Select(i => i).ToListAsync();
            return suburbs;
        }
        */

        // Offences Count by Suburb



        /* Get offences for given suburb & offencecodes
public async Task<object> CamerasInSuburb(string suburb)
{
    var cameraContext = _context.CameraCodes;
    var suburbs = await cameraContext.Where(i => i.Suburb.ToLower().StartsWith(suburb.ToLower())).Select(i => i).ToListAsync();
    return suburbs;
}
*/




        // GET: /api/Graphs/OffenceDetail/A002
       /* [HttpGet("{offenceCode}")]
        public async Task<object> OffenceDetail(string offenceCode)
        {
            var offence = await _context.Offences
                .FindAsync(offenceCode);
            if (offence == null)
            {
                return NotFound();
            }
            return offence;
        }
       */

    }
}
